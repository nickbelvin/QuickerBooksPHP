
<head>
    <title>WELCOME :: QUICKER BOOKS</title>
    <!-- Meta-Tags -->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta charset="utf-8">
    <meta name="keywords" content="Quicker Books Register">
    <script>
        addEventListener("load", function () {
            setTimeout(hideURLbar, 0);
        }, false);
        function hideURLbar() {
            window.scrollTo(0, 1);
        }
    </script>
    <!-- //Meta-Tags -->
    <!-- Index-Page-CSS -->
    <link rel="stylesheet" href="Templates/Login/css/style.css" type="text/css" media="all">
    <!-- //Custom-Stylesheet-Links -->
    <!--fonts -->
    <!-- //fonts -->
    <link rel="stylesheet" href="Templates/Login/css/font-awesome.min.css" type="text/css" media="all">
    <!-- //Font-Awesome-File-Links -->
    <!-- Google fonts -->
    <link href="//fonts.googleapis.com/css?family=Quattrocento+Sans:400,400i,700,700i" rel="stylesheet">
    <link href="//fonts.googleapis.com/css?family=Mukta:200,300,400,500,600,700,800" rel="stylesheet">
    <!-- Google fonts -->

       </head>
<div class="bgimg">
<div class="bottom-grid">
			<div class="logo">
				<h1>  <img src="assets/images/qb.png" alt="Your logo" title="Your logo"  style="height:55px;"/></h1>
			</div>
			<div class="links">
				<ul class="links-unordered-list">
					<li class="active">
						<a href="login.php" class="">Login</a>
					</li>	
					<li class="">
						<a href="signup.php" class="">Register</a>
					</li>
				</ul>
			</div>
		</div>

  <div class="middle">
    <h1>WELCOME TO QUICKER BOOKS!</h1>
    <hr>
    <p>Thanks for signing up. Check your email address for a confirmation email. </p>
  </div>
</div>
</div>
