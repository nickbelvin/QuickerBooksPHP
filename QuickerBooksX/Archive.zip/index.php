
<?php include( 'includes/logic/common_functions.php') ?>
<?php include( 'config.php') ?>
<?php include('navbar.php') ?>

<html>
<h4> Hello </h4>
</html>
