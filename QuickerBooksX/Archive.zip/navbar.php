<div class="container"> <!-- The closing container div is found in the footer -->
  <nav class="navbar navbar-default">
    <div class="container-fluid">
      <div class="navbar-header">
        <a class="navbar-brand" href="#">Quicker Books</a>
      </div>
      <ul class="nav navbar-nav navbar-right">
          <li><a href="<?php echo BASE_URL . 'signup.php' ?>"><span class="glyphicon glyphicon-user"></span> Sign Up</a></li>
          <li><a href="<?php echo BASE_URL . 'login.php' ?>"><span class="glyphicon glyphicon-log-in"></span> Login</a></li>
          <li><a href="<?php echo BASE_URL . 'accountsList.php' ?>"><span class=""></span>Accounts</a></li>
          <li><a href="<?php echo BASE_URL . 'admin/users/userList.php' ?>"><span class=""></span>Users</a></li>
      </ul>
    </div>
  </nav>